﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Bilet_14_Gushchina_220.Pages
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        public Authorization()
        {
            InitializeComponent();
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            var CurrentUser = ModelClasses.db.Users.FirstOrDefault(x => x.fullName == LoginBox.Text);

            if (CurrentUser != null)
            {
                switch (CurrentUser.Roles.name)
                {
                    case "Кассир":
                        NavigationService.Navigate(new Timetable());
                        break;
                    case "Пассажир":
                        NavigationService.Navigate(new BuyingATicket());
                        break;
                }
            }
            else
            {
                MessageBox.Show("Невернно введены данные");
            }
            //if (string.IsNullOrEmpty(LoginBox.Text))
            // {
            //     MessageBox.Show("Введите ФИО!");
            // }
            // using (var db = new Kvalif_Guzhina_220Entities())
            // {
            //     var user = db.Users
            //         .AsNoTracking()
            //         .FirstOrDefault(u => u.fullName == LoginBox.Text);

            //     if (user == null)
            //     {
            //         MessageBox.Show("Пользователь не найден!");
            //         return;
            //     }
            //     MessageBox.Show("Добро пожаловать");

            //     if (user != null)
            //     {
            //         switch (user.Roles.name)
            //         {
            //             case "Кассир":
            //                 NavigationService.Navigate(new Timetable());
            //                 break;
            //             case "Пассажир":
            //                 NavigationService.Navigate(new BuyingATicket());
            //                 break;
            //         }
            //     }
            //     else
            //     {
            //         MessageBox.Show("Неверные данные!");
            //     }

        }
            
        }

        private void RegistrarionBut_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Registration());
        }
    }
}
