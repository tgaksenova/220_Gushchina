﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bilet_14_Gushchina_220.Classes
{
    internal class ModelClasses
    {
        public static Kvalif_Guzhina_220Entities db = new Kvalif_Guzhina_220Entities();
    }
}
